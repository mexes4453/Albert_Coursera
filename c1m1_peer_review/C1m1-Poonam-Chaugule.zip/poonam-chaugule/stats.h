/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * stats.h
 *In this programming assignment you will create a simple application that performs statistical analytics on a dataset.
 *
 *
 * Kendall Niles
 * 13 AUG 2021
 *
 */
#ifndef __STATS_H__
#define __STATS_H__


//Given an array of data and a length, prints the array to the screen
//Input: array
void print_array(unsigned int*);

//Given an array of data and a length, returns the median value
//Input: unsigned int array
//Output: unsigned int
unsigned int find_median(unsigned int*);

//Given an array of data and a length, returns the mean value
//Input: unsigned int array
//Output: unsigned int
unsigned int find_mean(unsigned int*);

//Given an array of data and a length, returns the maximum
//Input: unsigned int array
//Output: unsigned int
unsigned int find_maximum(unsigned int*);

//Given an array of data and a length, returns the minimum
//Input: unsigned int array
//Output: unsigned int
unsigned int find_minimum(unsigned int*);

// A function that prints the statistics of an array including minimum, maximum, mean, and median.
//Input: array
void print_statistics(unsigned int*);

/*Given an array of data and a length, sorts the array from largest to smallest.  (The zeroth Element should be the largest value, and the last element (n-1) should be the smallest value. ) To print data to the screen, you can use the printf function provided by the standard IO library (stdio.h). Each printed value should be nicely formatted with an indicator of the variable or index for each statistic value printed.*/
//Input: array
void sort_array(unsigned int*);



#endif /* __STATS_H__ */
