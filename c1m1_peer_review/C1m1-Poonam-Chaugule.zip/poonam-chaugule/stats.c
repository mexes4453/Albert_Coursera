/******************************************************************************
 * Copyright (C) 2017 by Alex Fosdick - University of Colorado
 *
 * Redistribution, modification or use of this software in source or binary
 * forms is permitted as long as the files maintain this copyright. Users are 
 * permitted to modify this and use it to learn about the field of embedded
 * software. Alex Fosdick and the University of Colorado are not liable for any
 * misuse of this material. 
 *
 *****************************************************************************/
/**
 * stats.c
 * Kendall Niles
 * 13 AUG 2021
 */



#include <stdio.h>
#include "stats.h"

/* Size of the Data Set */
#define SIZE (40)

void main() {

  unsigned char test[SIZE] = { 34, 201, 190, 154,   8, 194,   2,   6,
                              114, 88,   45,  76, 123,  87,  25,  23,
                              200, 122, 150, 90,   92,  87, 177, 244,
                              201,   6,  12,  60,   8,   2,   5,  67,
                                7,  87, 250, 230,  99,   3, 100,  90};
unsigned int temp[SIZE];
for(int i=0; i<=SIZE; i++){
temp[i] = (unsigned int) test[i];
}


sort_array(temp);
print_array(temp);
print_statistics(temp);

}

// A function that prints the statistics of an array including minimum, maximum, mean, and median.
void print_statistics(unsigned int *arr){
	unsigned int min = find_minimum(arr);
	unsigned int max = find_maximum(arr);
	unsigned int mean = find_mean(arr);
	unsigned int median = find_median(arr);
	printf("-------------------------------------\n The max: %i\n The min: %i\n The mean: %i\n The median: %i\n",max, min, mean, median);

}


//Given an array of data and a length, prints the array to the screen
void print_array(unsigned int *arr){
	for (int i =0; i< SIZE; i++)
		{
			printf( " %i: %i \n", i, arr[i]);
		}
}
//Given an array of data and a length, returns the median value
unsigned int find_median(unsigned int *arr){
    unsigned int median=0;
   
    // if number of elements are even
    if(SIZE%2 == 0)
        median = (arr[(SIZE-1)/2] + arr[SIZE/2])/2.0;
    // if number of elements are odd
    else
        median = arr[SIZE/2];
    
    return median;
}
//Given an array of data and a length, returns the mean value
unsigned int find_mean(unsigned int *arr){

   int  i, sum = 0;       
   unsigned int avg;          
 
   for (i = 0; i < SIZE; ++i) {
      sum += arr[i];
   }
 
   avg = (double)sum / SIZE;
   return avg;
}
//Given an array of data and a length, returns the maximum
unsigned int find_maximum(unsigned int *arr){
	return arr[0];
}
//Given an array of data and a length, returns the minimum
unsigned int find_minimum(unsigned int *arr){
	return arr[SIZE - 1];
}
/*Given an array of data and a length, sorts the array from largest to smallest.  (The zeroth Element should be the largest value, and the last element (n-1) should be the smallest value. ) To print data to the screen, you can use the printf function provided by the standard IO library (stdio.h). Each printed value should be nicely formatted with an indicator of the variable or index for each statistic value printed.*/
void sort_array(unsigned int *arr){
	int a, i, j;
           for (i = 0; i < SIZE; ++i) 
        {
            for (j = i + 1; j < SIZE; ++j) 
            {
                if (arr[i] < arr[j]) 
                {
                    a = arr[i];
                    arr[i] = arr[j];
                    arr[j] = a;
                }
            }
        }
}
