introduction to embedded systems and development environment

week 1 Assignment

checkout stats.c and stats.h
 
