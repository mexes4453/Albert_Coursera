/*********************************************************************
 * Author  : UDOH CHIEMEZIE ALBERT
 * Project : STATISTICS 
 * Date    : 15.08.2021
 * 
 * Description
 *     This program analyzes an array of unsigned char data items
 *     and report statistics analysis of the data sets which includes
 *     > Maximum
 *     > Minumum
 *     > Mean
 *     > Media
 * 
**********************************************************************/

